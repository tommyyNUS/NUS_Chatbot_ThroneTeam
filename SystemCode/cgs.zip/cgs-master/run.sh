source activate cgs
python src/app.py