# Anaconda
conda env create -f environment.yml
source activate cgs
python -c 'import nltk; nltk.download("punkt"); nltk.download("wordnet")'
python -m spacy download en_core_web_md
echo Setup Complete!