# Anaconda
conda env create -f environment.yml
conda activate cgs
python -c 'import nltk; nltk.download("punkt"); nltk.download("wordnet")'

# InferSent
cd src/InferSent/
curl -Lo dataset/fastText/crawl-300d-2M.vec.zip https://dl.fbaipublicfiles.com/fasttext/vectors-english/crawl-300d-2M-subword.zip
unzip dataset/fastText/crawl-300d-2M.vec.zip -d dataset/fastText/

export fileid=1sfIlbc8C5k_CujTF7UrtW_2lvNIH-EhW
export filename=encoder/infersent2.pkl

curl -c ./cookie -s -L "https://drive.google.com/uc?export=download&id=${fileid}" > /dev/null
curl -Lb ./cookie "https://drive.google.com/uc?export=download&confirm=`awk '/download/ {print $NF}' ./cookie`&id=${fileid}" -o ${filename}
rm -f cookie

echo Setup Complete!