def get_file_path(domain):
    """ 
    func to convert domain to actual document path
    """
    fp_dict = {
        "artificial intelligence":                     "executiveEducation/artificial-intelligence.txt",
        "cybersecurity":                               "executiveEducation/cybersecurty.txt",
        "digital science":                             "executiveEducation/data-science",
        "digital agility":                             "executiveEducation/digital-agility.txt",
        "digital innovation":                          "executiveEducation/digital-innovation-design.txt",
        "digital products":                            "executiveEducation/digital-products-platforms.txt",
        "digital strategy":                            "executiveEducation/digital-strategy-leadership.txt",
        "professional coversion programme":            "executiveEducation/professional-conversion-programmes.txt",
        "smart health leadership":                     "executiveEducation/professional-diploma-in-smart-health-leadership.txt",
        "skill future series":                         "executiveEducation/skillsfuture-series.txt",
        "software systems":                            "executiveEducation/software-systems.txt",
        "stackup-startup ":                            "executiveEducation/stackup---startup-tech-talent-development.txt",
        "contact us":                                  "generalInfo/contact-us.txt",
        "director's ceo welcome":                      "generalInfo/director-ceo's-welcome.txt",
        "getting to nus":                              "generalInfo/getting-to-nus.txt",
        "achievements":                                "generalInfo/our-achievements.txt",
        "management board":                            "generalInfo/our-management-board.txt",
        "story":                                       "generalInfo/our-story.txt",
        "why nus-iss":                                 "generalInfo/why-nus-iss.txt",
        "graduate diploma in system analysis":         "graduateProgrammes/graduate-diploma-in-systems-analysis.txt",
        "m.tech in digital leadership":                "graduateProgrammes/master-of-technology-in-digital-leadership.txt",
        "m.tech in enterprise business analytics":     "graduateProgrammes/master-of-technology-in-enterprise-business-analytics.txt",
        "m.tech in intelligent systems":               "graduateProgrammes/master-of-technology-in-intelligent-systems.txt",
        "m.tech in software engineering":              "graduateProgrammes/master-of-technology-in-software-engineering.txt",
        "business analytics":                          "stackableProgrammes/business-analytics.txt",
        "certificate in digital solution development": "stackableProgrammes/intelligent-systems.txt",
        "software engineering":                        "stackableProgrammes/software-engineering.txt",
    }

    return fp_dict.get(domain.lower())


def map_qtype(q_word):
    q_word = q_word[0].lower()
    q_dict = {
        "what":        "NNP",
        "who":         "PERSON",
        "where":       "LOC",
        "when":        "DATE",
        "how":         "NNP",
        "which":       "NNP",
        "information": "DEFINITION",
        "details":     "DEFINITION",
    }
    return q_dict.get(q_word)


if __name__ == "__main__":
    print(get_file_path("intelligent systems"))