def warn(*args, **kwargs):
    pass


import warnings

warnings.warn = warn

import spacy as sp
import nltk
from nltk import ngrams
from textblob import TextBlob
import string
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import util
import pathlib


class QAModel:
    def __init__(self):

        # Env Variables
        self.DATA_PATH = "./data/"

        # SpaCy setup
        self.nlp = sp.load("en_core_web_md")

    def LemTokens(self, tokens):
        lemmer = nltk.stem.WordNetLemmatizer()
        return [lemmer.lemmatize(token) for token in tokens]

    def LemNormalize(self, text):
        remove_punct_dict = dict((ord(punct), None) for punct in string.punctuation)
        return self.LemTokens(
            nltk.word_tokenize(text.lower().translate(remove_punct_dict))
        )

    def get_ngrams(self, text, n=3):
        tokens = self.LemTokens(text)
        ng = set(ngrams(tokens, n))
        return ng

    def get_paragraphs(self, raw_text):
        paragraphs = [
            para.strip().lower()
            for para in raw_text.split("\n\n")
            if len(para.strip()) > 0
        ]

        return paragraphs

    def compute_jaccard_sim(self, question, sentence, n=2):
        if len(self.LemTokens(question)) < n or len(self.LemTokens(sentence)) < n:
            return 0
        else:
            question_ngram = self.get_ngrams(question, n)
            sentence_ngram = self.get_ngrams(sentence, n)
            similarity = len(question_ngram.intersection(sentence_ngram)) / len(
                question_ngram.union(sentence_ngram)
            )
        return similarity

    def get_relevant_paragraphs(self, paragraphs, question, n=4):

        TfidfVec = TfidfVectorizer(tokenizer=self.LemNormalize, stop_words="english")
        paragraphs.append(question[0])
        tfidf = TfidfVec.fit_transform(paragraphs)
        vals = cosine_similarity(tfidf[-1], tfidf)
        ids = vals.flatten().argsort()[-n:-1][::-1]

        return [paragraphs[idx] for idx in ids]

    def get_relevant_sentences(self, paragraphs, question):
        sentences = [
            sentence.raw for para in paragraphs for sentence in TextBlob(para).sentences
        ] 

        print("\nSENTENCES\n=============================================\n")
        for sent in sentences:
            print(sent)       
            print(self.compute_jaccard_sim(question, sent))
            print()
        sim_score = np.array(
            [self.compute_jaccard_sim(question, sent, n=3) for sent in sentences]
        )
        ids = sim_score.flatten().argsort()[-3:][::-1]

        return [sentences[idx] for idx in ids]

    def get_answer(self, sentences, q_type):
        q_type = q_type.upper()
        answer = None
        parsed_sentences = [self.nlp(sent) for sent in sentences]
        noun_chunks = [
            chunk
            for parsed_sent in parsed_sentences
            for chunk in parsed_sent.noun_chunks
        ]

        if q_type == "PERSON":
            temp = []
            for sent in parsed_sentences:
                for ent in sent.ents:
                    if ent.label_ == "PERSON":
                        temp.append(ent.text)

            answer = ", ".join(temp)

        elif q_type == "LOCATION":
            temp = []
            for sent in parsed_sentences:
                for ent in sent.ents:
                    if ent.label_ == "LOC":
                        temp.append(ent.text)

            answer = ", ".join(temp)

        elif q_type == "ORG":
            temp = []
            for sent in parsed_sentences:
                for ent in sent.ents:
                    if ent.label_ == "ORG":
                        temp.append(ent.text)

            answer = ", ".join(temp)

        elif q_type == "DATE":
            temp = []
            for sent in parsed_sentences:
                for ent in sent.ents:
                    if ent.label_ == "DATE":
                        temp.append(ent.text)

            answer = ", ".join(temp)

        elif q_type in ["NN", "NNP"]:
            temp = []
            noun_chunks = [
                chunk
                for parsed_sent in parsed_sentences
                for chunk in parsed_sent.noun_chunks
            ]
            temp = [chunk.text for chunk in noun_chunks]

            answer = "Here's what I found: " + ", \n".join(sentences)

        elif q_type == "DEFINITION":
            answer = "Here's what I found: " + ", \n".join(sentences)


        print("\nENTITIES\n=============================================\n")
        for doc in parsed_sentences:
            for ent in doc.ents:
                print(ent.text, ent.label_)
        print("\nCHUNKS\n=============================================\n")
        for chunk in noun_chunks:
            print(chunk.text)

        if answer == None or len(answer) == 0:
            answer = "Sorry I couldn't find what you're looking for. Please be more specific."

        return answer

    def query(self, domain, question, q_word, specific_query):
        # return ', '.join([str(domain), str(question), str(q_word)])
        q_type = util.map_qtype(q_word)
        doc_path = pathlib.Path(util.get_file_path(domain))
        full_path = pathlib.Path(self.DATA_PATH).joinpath(doc_path)
        with open(full_path, "r") as file:
            text = file.read()

        paragraphs = self.get_paragraphs(text)
        relevant_paras = self.get_relevant_paragraphs(paragraphs, question)
        print("\nRELEVANT PARAGRAPHS\n==================================================\n")
        for para in relevant_paras:
            print(para)
            print("\n")
        relevant_sentences = self.get_relevant_sentences(relevant_paras, question)
        print("\nRELEVANT SENTENCES\n=============================================\n")
        for sent in relevant_sentences:
            print(sent)       
        answer = self.get_answer(relevant_sentences, q_type)
        # for sent in self.get_relevant_sentences(relevant_paras, question):
        #     print("\n")
        #     print("-" * 101)
        #     print(sent)
        print(answer)
        return answer


if __name__ == "__main__":
    qa = QAModel()
    questions = [
        "what is the intelligent systems course about",
        "can you tell me what the course fees are for singaporeans",
        "what are some courses",
        "when is the ",
    ]
    domain = "intelligent systems"  # REMEMBER TO DELETE
    # question = ["what courses are in the intelligent systems course"]
    q_type = "na"
    # qa.query(domain, question, q_type)
    for i in range(len(questions)):
        question = [questions[i]]
        print("============================= QUESTION ===============================")
        print(question)
        qa.query(domain, question, q_type)

    # while True:
    #     inp = input("Enter Question: ")
    #     qa.query(intent, [inp], q_type)
