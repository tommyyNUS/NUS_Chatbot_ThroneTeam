#!/usr/bin/env python

from flask import Flask, request, make_response, jsonify
import requests
from QAModel import QAModel


def getjson(url):
    response = requests.get(url)
    return response.json()

app = Flask(__name__)
@app.route("/", methods=["POST"])
def webhook():
    req = request.get_json(silent=True, force=True)
    domain = req["queryResult"]["parameters"]["DomainList"]
    question = req['queryResult']["queryText"]
    q_word = req['queryResult']["parameters"]["QnWord"]
    specific_query = req['queryResult']["parameters"]['specificquery']
    response_text = qa.query(domain, question, q_word, specific_query)

    return make_response(jsonify({"fulfillmentText": response_text}))


if __name__ == "__main__":
    qa = QAModel()
    app.run(debug=True, host="localhost", port=5050)